/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ds;

import java.util.*;
import java.lang.Math;

 class Postfix {
    public int choice(String s) {
        switch(s) {
	        case "+":
	        case "-": return 1;
	                 
                case "*":
	        case "/": return 2;
                
                case "^": return 3;
	     
                case "$":return 0; 
                
	    }
        return 0;
    }
}

/**
 *
 * @author Acer
 */
public class DS {

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /*Scanner sc = new Scanner(System.in);
        String s;
        s = sc.nextLine(); //input string
        god s1 = new god();
        s = s1.god(s);
        System.out.println(s);*/
    }
}

class god {
    String god(String s) {
        final int MAX = 16;
        final int MIN = -6;
        String temp = "";
        int l = s.length();
        String infix[]=new String[100]; // infix string
        int j=0,br=0;
        boolean flag = true;  //sends the things in brackets to temp for calling god
        boolean ignore = true;//to ignore brackets "(" and ")"
        boolean ignore2 = true;//to accept negative inputs based on few assumptions
        //boolean ignore3 = true;
        
        //converts input to infix
        for(int i=0 ; i < l ; i++ , ignore = true, ignore2 = true) {
            char ch = s.charAt(i);
            
            //infix space ready
            if(infix[j] == null) {
                infix[j] = "";
            }
            
            //brackets detect
            if(ch=='(') { 
                int initial = br;
                br++;    
                flag = false;
                if(initial == 0 && br == 1) {//toggles from 0 to 1
                    ignore = false;
                    temp = "";
                }
            }
            else if(ch == ')') {
                br--;
            }
            /*else if(l == i && br == 1) {
                br = 0;
                ignore3 = true;
            }*/
                
            // unnary negative
            if(s.charAt(i) == '-') {
                if(i == 0 || (s.charAt(i-1) == '+' || s.charAt(i-1) == '-' || s.charAt(i-1) == '*' || s.charAt(i-1) == '/' || s.charAt(i-1) == '^'))
                    ignore2 = false;
            }
            
            //differentiates opperator and operand
            if((flag) && (ignore2) && (s.charAt(i) == '+' || s.charAt(i) == '-' || s.charAt(i) == '*' || s.charAt(i) == '/' || s.charAt(i) == '^')) {
                j++;
                infix[j] = "";
                infix[j] += s.charAt(i);
                j++;
            }
            else {
                //calls god on bracket closure
                if(br == 0 && !flag) {
                    System.out.println(temp);
                    temp = god(temp);
                    infix[j] += temp;
                    ignore = false;
                    flag = true;
                }
                if(ignore) {
                    temp += ch;
                }
                if(flag && ignore) {
                    infix[j] += ch;
                }
            }
        }
        
        //prints infix in [] brackets
        int i = 0;
        while(infix[i] != null) {
            System.out.print("[" + infix[i] + "]");
            //if(infix[i].equals(pi))
            i++;
        }     
        System.out.println("\n");
        
        //infix to postfix
        i = 0;
        Stack o = new Stack();
        o.push("$");
        Postfix post = new Postfix();
        String[] pf= new String[100];
        int k = 0;
        int inst, incm;
        while(infix[k] != null) {
            boolean a = infix[k].equals(Character.toString('+'));
            boolean b = infix[k].equals(Character.toString('-'));
            boolean c = infix[k].equals(Character.toString('*'));
            boolean d = infix[k].equals(Character.toString('/'));
            boolean e = infix[k].equals(Character.toString('^'));
            
            //checks if operatr present
            if(a || b || c || d || e){
                inst = post.choice((String) o.peek());
                incm = post.choice(infix[k]);
                //System.out.print(inst +" "+ incm);
                while(incm <= inst) {
                    pf[i] = (String) o.pop();
                    inst = post.choice((String) o.peek());
                    i++;
                }
                o.push(infix[k]);
            }
            else {
                pf[i] = (infix[k]);
                i++;
            }
            k++;
        }
        //completes postfix by making opertor stack empty
        inst = post.choice((String) o.peek());
        while(inst != 0) {
            pf[i] = (String) o.pop();
            inst = post.choice((String) o.peek());
            i++;
        }
        
        //prints infix
        i = 0;
        System.out.print("Infix: ");
        while(infix[i] != null) {
            System.out.print("(" + infix[i] + ")");
            i++;
        }
        // end of infix to postfix
        
        //prints postfix and functions are also evaluated
        System.out.print("\n");
        i = 0;
        System.out.print("Postfix: ");
        while(pf[i] != null) {
            System.out.print("(" + pf[i] + ")");
            if(pf[i].matches("tanh(.*)")) {
                String tem = "";
                for(int g = 4 ; g<pf[i].length();g++)
                    tem+=pf[i].charAt(g);
                pf[i]= Double.toString(Math.tanh(Double.parseDouble(tem)));
                    System.out.println("test");
            }
            else if(pf[i].matches("sinh(.*)")) {
                String tem = "";
                for(int g = 4 ; g<pf[i].length();g++)
                    tem+=pf[i].charAt(g);
                pf[i]= Double.toString(Math.sinh(Double.parseDouble(tem)));
                    System.out.println("test");
            }
            else if(pf[i].matches("cosh(.*)")) {
                String tem = "";
                for(int g = 4 ; g<pf[i].length();g++)
                    tem+=pf[i].charAt(g);
                pf[i]= Double.toString(Math.cosh(Double.parseDouble(tem)));
                    System.out.println("test");
            }
            else if(pf[i].matches("(.*)°(.*)")) {
                    String tem = "";
                    for(int q = 0 ; q<pf[i].length()-1 ; q++)
                            tem+=pf[i].charAt(q);
                    double num = Double.parseDouble(tem);
                    num = num * Math.PI / 180;
                    tem = Double.toString(num);
                    System.out.println("hiiiiiiii"+num);
                    pf[i] = tem;
                }
            if(pf[i].matches("sin(.*)")) {
                String tem = "";
                for(int g = 3 ; g<pf[i].length();g++)
                    tem+=pf[i].charAt(g);
                pf[i]= Double.toString(Math.sin(Double.parseDouble(tem)));
                    System.out.println("test");
            }
            else if(pf[i].matches("cos(.*)")) {
                String tem = "";
                for(int g = 3 ; g<pf[i].length();g++)
                    tem+=pf[i].charAt(g);
                pf[i]= Double.toString(Math.cos(Double.parseDouble(tem)));
                    System.out.println("test");
            } 
            else if(pf[i].matches("tan(.*)")) {
                String tem = "";
                for(int g = 3 ; g<pf[i].length();g++)
                    tem+=pf[i].charAt(g);
                pf[i]= Double.toString(Math.tan(Double.parseDouble(tem)));
                    System.out.println("test");
            }
            else if(pf[i].matches("log10(.*)")) {
                String tem = "";
                for(int g = 5 ; g<pf[i].length();g++)
                    tem+=pf[i].charAt(g);
                pf[i]= Double.toString(Math.log10(Double.parseDouble(tem)));
                    System.out.println("test");
            }
            else if(pf[i].matches("log(.*)")) {
                String tem = "";
                for(int g = 3 ; g<pf[i].length();g++)
                    tem+=pf[i].charAt(g);
                pf[i]= Double.toString(Math.log(Double.parseDouble(tem)));
                    System.out.println("test");
            }
            else if(pf[i].matches("sqrt(.*)")) {
                String tem = "";
                for(int g = 4 ; g<pf[i].length();g++)
                    tem+=pf[i].charAt(g);
                pf[i]= Double.toString(Math.sqrt(Double.parseDouble(tem)));
                    System.out.println("test");
            }
            else if(pf[i].matches("round(.*)")) {
                String tem = "";
                for(int g = 5 ; g<pf[i].length();g++)
                    tem+=pf[i].charAt(g);
                pf[i]= Double.toString(Math.round(Double.parseDouble(tem)));
                    System.out.println("test");
            }
            else if(pf[i].matches("abs(.*)")) {
                String tem = "";
                for(int g = 3 ; g<pf[i].length();g++)
                    tem+=pf[i].charAt(g);
                pf[i]= Double.toString(Math.abs(Double.parseDouble(tem)));
                    System.out.println("test");
            }
            else if(pf[i].matches("floor(.*)")) {
                String tem = "";
                for(int g = 5 ; g<pf[i].length();g++)
                    tem+=pf[i].charAt(g);
                pf[i]= Double.toString(Math.floor(Double.parseDouble(tem)));
                    System.out.println("test");
            }
            else if(pf[i].matches("(.*)π(.*)")) {
                 pf[i] = Double.toString(Math.PI);
            }
            else if(pf[i].matches("(.*)e(.*)")) {
                 pf[i] = Double.toString(Math.E);
            }
            i++;
        }
        
        System.out.print("\n");
        
        //evaluation of postfix expression
        i = 0;
        j = -1;
        double ans[] = new double[10];
        while(pf[i] != null) {
            boolean a = pf[i].equals(Character.toString('+'));
            boolean b = pf[i].equals(Character.toString('-'));
            boolean c = pf[i].equals(Character.toString('*'));
            boolean d = pf[i].equals(Character.toString('/'));
            boolean e = pf[i].equals(Character.toString('^'));
            if(a || b || c || d || e) {
                switch(pf[i]) {
                    case "+":
                        j--;
                        ans[j] = ans[j] + ans[j+1];
                        break;
                        
                    case "-":
                        j--;
                        ans[j] = ans[j] - ans[j+1];
                        break;
                        
                    case "/":
                        j--;
                        ans[j] = ans[j] / ans[j+1];
                        break;
                      
                    case "*":  
                        j--;
                        ans[j] = ans[j] * ans[j+1];
                        break;                
                
                    case "^":  
                        j--;
                        ans[j] = Math.pow(ans[j],ans[j+1]);
                        break;       
                }
            }
            else {
                //eval.push(Double.parseDouble(pf[i]));
                j++;
                ans[j] = Double.parseDouble(pf[i]);
                //System.out.println("Test3"+" "+ans[j]+" "+j);
            }
            i++;
        }
        
        //limit check
        if(ans[0] > Math.pow(10,MAX)){
            temp = "Infinity";//Double.toString(1/0);
            System.out.println("too big");
        }
        else if(ans[0] < -Math.pow(10,MAX)){
            temp = "-Infinity";//Double.toString(1/0);
            System.out.println("too big");
        }
        else if (ans[0] < Math.pow(10,MIN) && ans[0] > 0){
            temp = "0.0";
            System.out.println("too small");
        }
        else
            temp = Double.toString(ans[0]);//answer stored in ans[0]
        
        //prints answer in String form
        System.out.println(temp);
        return temp;
    }
}

