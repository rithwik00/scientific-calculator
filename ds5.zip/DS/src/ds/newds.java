package ds;

import java.util.Scanner;

class newds {
    public static void main(String args[]) {
        String[] infix = new String[100];
        Scanner sc = new Scanner(System.in);
        String input;
        input = sc.nextLine();
        
    }
}