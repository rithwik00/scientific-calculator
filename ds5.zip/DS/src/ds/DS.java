/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ds;

import java.util.*;


 class Postfix {
    
    public int choice(String s) {
        switch(s) {
	        case "+":
	        case "-": return 1;
	                 
                case "*":
	        case "/": return 2;
                
                case "^": return 3;
	     
                case "$":return 0; 
                
	    }
        return 0;
    }
}

/**
 *
 * @author Acer
 */
public class DS {

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        
        Scanner sc = new Scanner(System.in);
        String s;
        s = sc.nextLine(); //input string
        god s1 = new god();
        s = s1.god(s);
        //System.out.println(s);
    
    }
}

class god {
    String god(String s) {  
        String temp = "";
        int l = s.length();
        String infix[]=new String[100]; // infix string
        int j=0,br=0;
        boolean flag = true;//normal stuff flag
        boolean ignore = true;
        for(int i=0 ; i < s.length() ; i++ , ignore = true) { //converts input to infix
            char c = s.charAt(i);
            //boolean flag = true;
            //infix space ready
            if(infix[j] == null) {
                infix[j] = "";
            }
            if(c=='(') { 
                int initial = br;
                br++;    
                flag = false;
                if(br - initial == 1 && br == 1) {//toggles from 0 to 1
                    ignore = false;
                    temp = "";
                }
            }
            else if(c == ')') {
                //i++;
                //c = s.charAt(i);
                //flag = true;
                br--;
            }
            if((flag) && (s.charAt(i) == '+' || s.charAt(i) == '-' || s.charAt(i) == '*' || s.charAt(i) == '/')) {
                j++;
                infix[j] = "";
                infix[j] += s.charAt(i);
                j++;
            }
            else {
                if(br == 0 && !flag) {
                    flag = true;
                    //temp += infix[j];
                    //for(int k=0 ; k<infix[j].length() ; k++)
                    //        temp += infix[j].charAt(k);
                    System.out.println(temp);
                    temp = god(temp);
                    infix[j] += temp;
                    //j++;
                    ignore = false;
                    flag = true;
                }
                if(ignore) {
                    //infix[j] += c;
                    temp += c;
                }
                if(flag && ignore) {
                    infix[j] += c;
                }
                
            }
        }
        int i = 0;
        while(infix[i] != null) {
            System.out.print("[" + infix[i] + "]");
            i++;
        }     
        System.out.println("\n");
        //return ;
        //}
        i = 0;
        Stack o = new Stack();
        o.push("$");
        Postfix post = new Postfix();
        String[] pf= new String[100];
        int k = 0;
        int inst, incm;
        while(infix[k] != null) {
            //System.out.println(infix[k].equals(Character.toString('+')));
            boolean a = infix[k].equals(Character.toString('+'));
            boolean b = infix[k].equals(Character.toString('-'));
            boolean c = infix[k].equals(Character.toString('*'));
            boolean d = infix[k].equals(Character.toString('/'));
            if(a || b || c || d){
                inst = post.choice((String) o.peek());
                incm = post.choice(infix[k]);
                //System.out.print(inst +" "+ incm);
                while(incm <= inst) {
                    pf[i] = (String) o.pop();
                    inst = post.choice((String) o.peek());
                    i++;
                }
                o.push(infix[k]);       
                //System.out.println("Test1" + o + pf[i]);
            }
            
            else {
                pf[i] = (infix[k]);
                //System.out.println("Test2" + o + pf[i]);
                i++;
            }
            k++;
        }
        inst = post.choice((String) o.peek());
        while(inst != 0) {
            pf[i] = (String) o.pop();
            inst = post.choice((String) o.peek());
            i++;
        }
        i = 0;
        System.out.print("Prefix: ");
        while(infix[i] != null) {
            System.out.print("(" + infix[i] + ")");
            i++;
        }
        System.out.print("\n");
        i = 0;
        System.out.print("Postfix: ");
        while(pf[i] != null) {
            System.out.print("(" + pf[i] + ")");
            if(pf[i].matches("sin(.*)")) {
                String tem = "";
                for(int g = 3 ; g<pf[i].length();g++)
                    tem+=pf[i].charAt(g);
                pf[i]= Double.toString(Math.sin(Double.parseDouble(tem)));
                    System.out.println("test");
            }
            i++;
        }
        System.out.print("\n");
        //Stack eval = new Stack();
        i = 0;
        j = -1;
        
        double ans[] = new double[10];
        while(pf[i] != null) {
            boolean a = pf[i].equals(Character.toString('+'));
            boolean b = pf[i].equals(Character.toString('-'));
            boolean c = pf[i].equals(Character.toString('*'));
            boolean d = pf[i].equals(Character.toString('/'));
            if(a || b || c || d) {
                switch(pf[i]) {
                    case "+":
                        //System.out.println("Test4"+" "+ans[j]+" "+j);
                        j--;
                        ans[j] = ans[j] + ans[j+1];
                        //System.out.println("Test5"+" "+ans[j]+" "+j);
                        break;
                        
                    case "-":
                        j--;
                        ans[j] = ans[j] - ans[j+1];
                        break;
                        
                    case "/":
                        j--;
                        ans[j] = ans[j] / ans[j+1];
                        break;
                      
                    case "*":  
                        j--;
                        ans[j] = ans[j] * ans[j+1];
                        break;                
                
                }
            }
            else {
                //eval.push(Double.parseDouble(pf[i]));
                j++;
                ans[j] = Double.parseDouble(pf[i]);
                //System.out.println("Test3"+" "+ans[j]+" "+j);
            }
            i++;
        }
        temp = Double.toString(ans[0]);
        //System.out.println(o+"stack");
        i = 0;
        /*while(pf[i] != null) {
             System.out.print("[" + pf[i] + "]");
             i++;
        }*/
        System.out.println(temp);
        return temp;
        }
}

